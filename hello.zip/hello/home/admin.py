from django.contrib import admin
from home.models import User
class serviceadmine(admin.ModelAdmin):
  desplay_list=("name","email","phone","desc","date")
admin.site.register(User,serviceadmine)
  

# Register your models here.
